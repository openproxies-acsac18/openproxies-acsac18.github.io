java -cp code/jar/package.jar edu.georgetown.cs.seclab.ManualFetch "$@"
