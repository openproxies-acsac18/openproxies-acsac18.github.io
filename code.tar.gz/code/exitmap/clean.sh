rm -rf logs/* jsons/* files/* temp/* exitmap_tor_datadir*/*
mkdir jsons/tmp