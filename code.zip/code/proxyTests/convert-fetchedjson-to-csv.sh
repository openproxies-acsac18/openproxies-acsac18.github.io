json2csv -i $1 -f proxyName,proxyProtocol,url,completed,httpStatus,expectedContent,reason,headers,fetchTime,contentFilename,certCorrect,certCompleted,certFilename
