* get xroxy list at http://madison.xroxy.com/download.php?filepath=downloadFLP2Bw&filename=XROXY-All_types-Any_port-All_countries
  * compressed 
  * no longer available
  * 

* see https://github.com/clarketm/proxy-list, specifically: ```curl -s "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list.txt" | sed '1,2d; $d; s/\s.*//; /^$/d' > proxy-list.txt```  
 * around 300 or so
 * updated daily
 * can be automated
 * DONE!
 
* see https://freeproxylist.org/en/free-proxy-list.htm
 * has CAPTCHA to prevent automation
 * ~ 3000
 * NOT AUTOMATABLE

* http://www.freeproxy.ru/download/lists/goodproxy.txt 
  * HTTP proxy list as of last week
  * DONE!  [maybe]

* multiproxy: http://multiproxy.org/txt_all/proxy.txt
  * looks like last update is 11-Feb-2009 (see http://multiproxy.org/all_proxy.htm)
  * DONE!

* multiproxy2: http://multiproxy.org/txt_anon/proxy.txt
  * DONE! 

* (workingprocies) http://www.workingproxies.org/plain-text
  * ~ 2000
  * DONE!

* [proxydaily] http://proxy-daily.com/2017/10/05-10-2017-proxy-list-4/
  * scrapable  
  * DONE!

* https://crackingking.com/thread-79018.html
  * very sketchy
  * ~10K
  * dated 5-4-2016
  * NOT DONE!  TOO OLD
 