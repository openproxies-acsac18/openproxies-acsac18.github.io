basic definition at https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/CONNECT


see https://pypi.python.org/pypi/httpsproxy_urllib2
see https://urllib3.readthedocs.io/en/latest/advanced-usage.html#proxies
see https://code.activestate.com/recipes/456195-urrlib2-opener-for-ssl-proxy-connect-method/
